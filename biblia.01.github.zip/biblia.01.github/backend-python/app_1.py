from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import google.generativeai as genai
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "segredo_super_seguro"

# Configuração da API Gemini
API_KEY = "AIzaSyBRbLtqr6q0bb8u8_Jxwk0gkiqkXlFyzKo"
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-2.0-flash")

# Caminho do arquivo de usuários
USUARIOS_PATH = "usuarios.json"

# Funções auxiliares para JSON
def carregar_usuarios():
    if os.path.exists(USUARIOS_PATH):
        with open(USUARIOS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def salvar_usuarios(usuarios):
    with open(USUARIOS_PATH, "w", encoding="utf-8") as f:
        json.dump(usuarios, f, indent=4, ensure_ascii=False)

# Rotas principais
@app.route("/")
def index():
    nome_usuario = session.get("nome")
    return render_template("index.html", usuario=nome_usuario)

@app.route("/cadastro")
def cadastro():
    return render_template("cadastro.html")

# Rota para cadastrar usuários
@app.route("/cadastrar", methods=["POST"])
def cadastrar():
    dados = request.get_json()
    usuarios = carregar_usuarios()

    if not all([dados.get("nome"), dados.get("email"), dados.get("senha")]):
        return jsonify({"sucesso": False, "mensagem": "Todos os campos são obrigatórios!"})

    if any(u["email"] == dados["email"] for u in usuarios):
        return jsonify({"sucesso": False, "mensagem": "Email já cadastrado!"})

    novo_usuario = {
        "nome": dados["nome"],
        "email": dados["email"],
        "senha": generate_password_hash(dados["senha"]),
        "perguntas": []
    }

    usuarios.append(novo_usuario)
    salvar_usuarios(usuarios)

    # Mantém sessão ativa após cadastro
    session["nome"] = dados["nome"]
    session["email"] = dados["email"]
    session["historico"] = []

    return jsonify({
        "sucesso": True,
        "mensagem": "Cadastro realizado com sucesso!",
        "redirect": "/"
    })

# Rota para fazer pergunta à IA com contexto
@app.route("/perguntar", methods=["POST"])
def perguntar():
    dados = request.get_json()
    pergunta = dados["pergunta"]

    # Carrega o histórico da sessão ou inicializa se não existir
    if "historico" not in session:
        session["historico"] = []
    
    # Adiciona a nova pergunta ao histórico
    session["historico"].append({"tipo": "pergunta", "conteudo": pergunta})

    # Pega os últimos 5 itens do histórico (perguntas e respostas)
    historico = session["historico"][-5:]

    # Formata o histórico para incluir no prompt
    contexto_formatado = []
    for item in historico:
        if item["tipo"] == "pergunta":
            contexto_formatado.append(f"Usuário: {item['conteudo']}")
        else:
            contexto_formatado.append(f"IA: {item['conteudo']}")

    contexto = "\n".join(contexto_formatado)

    prompt = (
        "Você é uma IA bíblica. Responda com base nas Escrituras. "
        "Seja clara, direta, e organizada e rapida. Use parágrafos para facilitar a leitura.\n\n"
        "Histórico recente da conversa (perguntas e respostas):\n"
        f"{contexto}\n\n"
        f"Pergunta atual: {pergunta}\n\n"
        "Considere o histórico acima para responder de forma contextualizada."
    )

    try:
        resposta = model.generate_content(prompt).text
    except Exception as e:
        return jsonify({"resposta": f"Erro ao processar a pergunta: {str(e)}"})

    # Adiciona a resposta ao histórico da sessão
    session["historico"].append({"tipo": "resposta", "conteudo": resposta})
    session.modified = True  # Garante que a sessão será salva

    # Salva no JSON se usuário estiver logado
    email = session.get("email")
    if email:
        usuarios = carregar_usuarios()
        for usuario in usuarios:
            if usuario["email"] == email:
                usuario["perguntas"].append({
                    "pergunta": pergunta,
                    "resposta": resposta
                })
                salvar_usuarios(usuarios)
                break

    return jsonify({"resposta": resposta})

if __name__ == "__main__":
    if not os.path.exists(USUARIOS_PATH):
        with open(USUARIOS_PATH, "w", encoding="utf-8") as f:
            json.dump([], f)

    app.run(debug=True)
    